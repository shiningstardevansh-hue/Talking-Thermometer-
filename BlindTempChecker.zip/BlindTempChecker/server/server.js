const express = require("express");
const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");

const app = express();
const port = 3000;

// Replace "COM3" with your Arduino port (check in Arduino IDE)
const serial = new SerialPort({ path: "COM3", baudRate: 9600 });
const parser = serial.pipe(new ReadlineParser({ delimiter: "\r\n" }));

let temperature = "0";

parser.on("data", (data) => {
  temperature = data;
  console.log("Temperature:", temperature);
});

app.get("/temp", (req, res) => {
  res.send(temperature);
});

app.listen(port, () =>
  console.log(`✅ Server running at http://localhost:${port}`)
);
